﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FitnessCenterOtomasyonu
{
    public partial class UyeGoruntule : Form
    {
        public UyeGoruntule()
        {
            InitializeComponent();
        }
        
        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection baglan = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\90554\Documents\FitnessDb.mdf;Integrated Security=True;Connect Timeout=30");
        private void uyeler()
        {
            baglan.Open();
            string sorgu = "select * from uye";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            baglan.Close();

        }
        private void button1_Click(object sender, EventArgs e)
        {
         
            SqlDataAdapter adapt;
            DataTable dt;
            baglan.Open();
            adapt = new SqlDataAdapter("select * from uye where adsoyad like '" + textBox1.Text + "%'", baglan);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            baglan.Close();
        }

        private void UyeGoruntule_Load(object sender, EventArgs e)
        {
            uyeler();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
