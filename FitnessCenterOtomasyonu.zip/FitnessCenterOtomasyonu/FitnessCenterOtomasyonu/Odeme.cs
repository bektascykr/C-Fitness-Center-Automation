﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FitnessCenterOtomasyonu
{
    public partial class Odeme : Form
    {
        public Odeme()
        {
            InitializeComponent();
        }
        SqlConnection baglan = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\90554\Documents\FitnessDb.mdf;Integrated Security=True;Connect Timeout=30");
        private void doldur()
        {
            baglan.Open();
          
            SqlCommand komut = new SqlCommand("select adsoyad from uye", baglan);
            SqlDataReader sdr;
            sdr = komut.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("adsoyad".ToString());
            dt.Load(sdr);
            comboBox1.ValueMember = "adsoyad";
            comboBox1.DataSource = dt;

            baglan.Close();

        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }
        private void ClearData()
        {
           textBox2.Text = "";
            comboBox1.Text = "";
           
           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ClearData();
        }
        private void uyeler()
        {
            baglan.Open();
            string sorgu = "select * from odeme";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            baglan.Close();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" | comboBox1.Text == "")
            {
                MessageBox.Show("Lütfen Ödeme İçin Veriyi Seçin!");
            }
            else
            {
                string odeme = dateTimePicker1.Value.Day.ToString() + "/" + dateTimePicker1.Value.Month.ToString()+"/"+ dateTimePicker1.Value.Year.ToString();
                baglan.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from odeme where uye='" + comboBox1.SelectedValue.ToString() + "' and ay='" + odeme + "'", baglan);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString()=="1")
                {
                    MessageBox.Show("Ödeme Zaten Yapıldı!");
                }
                else
                {
                    string sorgu = "insert into odeme values('"+odeme+"','"+comboBox1.SelectedValue.ToString()+"',"+textBox2.Text+")";
                    SqlCommand komut = new SqlCommand(sorgu, baglan);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Ödeme Başarıyla Yapıldı!");
                }
                baglan.Close();
                uyeler();
            }
        }

        private void Odeme_Load(object sender, EventArgs e)
        {
            doldur();
            uyeler();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adapt;
            DataTable dt;
            baglan.Open();
            adapt = new SqlDataAdapter("select * from odeme where uye like '" + textBox1.Text + "%'", baglan);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            baglan.Close();
        }
    }
}
