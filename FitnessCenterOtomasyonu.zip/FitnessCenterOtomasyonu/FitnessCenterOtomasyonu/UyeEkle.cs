﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace FitnessCenterOtomasyonu
{
    public partial class UyeEkle : Form
    {
        public UyeEkle()
        {
            InitializeComponent();
        }
        SqlConnection baglan = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\90554\Documents\FitnessDb.mdf;Integrated Security=True;Connect Timeout=30");

        private void label6_Click(object sender, EventArgs e)
        {
           
        }

        private void UyeEkle_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (AdSoyadTxt.Text==""||TelefonTxt.Text==""||odemeTxt.Text==""||YasTxt.Text=="")
            {
                MessageBox.Show("Eksik Bilgi Girdiniz!");

            }
            else
            {
                try
                {
                    baglan.Open();
                    string sorgu = "insert into uye values('" + AdSoyadTxt.Text + "','" + TelefonTxt.Text + "','" + cinsiyetComboBox.SelectedItem.ToString() + "','" + YasTxt.Text + "','" + odemeTxt.Text + "','" + zamanComboBox.SelectedItem.ToString() + "')";
                    SqlCommand kmt = new SqlCommand(sorgu, baglan);
                    kmt.ExecuteNonQuery();
                    MessageBox.Show("Başarıyla Eklendi!");
                    baglan.Close();



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                   
                }
                
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdSoyadTxt.Text = "";
            odemeTxt.Text = "";
            TelefonTxt.Text = "";
            YasTxt.Text = "";
            cinsiyetComboBox.Text = "";
            zamanComboBox.Text = "";
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }
    }
}
