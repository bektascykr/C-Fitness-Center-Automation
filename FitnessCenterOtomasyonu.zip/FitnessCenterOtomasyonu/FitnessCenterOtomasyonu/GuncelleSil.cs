﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace FitnessCenterOtomasyonu
{
    public partial class GuncelleSil : Form
    {
        public GuncelleSil()
        {
            InitializeComponent();
        }
        SqlConnection baglan = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\90554\Documents\FitnessDb.mdf;Integrated Security=True;Connect Timeout=30");
        private void uyeler()
        {
            baglan.Open();
            string sorgu = "select * from uye";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            baglan.Close();

        }
        private void GuncelleSil_Load(object sender, EventArgs e)
        {
            uyeler();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {

            if (ID != 0)
            {
                cmd = new SqlCommand("delete uye where id=@id", baglan);
                baglan.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.ExecuteNonQuery();
                baglan.Close();
                MessageBox.Show("Başarıyla Silindi!");
                uyeler();
                ClearData();
            }
            else
            {
                MessageBox.Show("Lütfen Silinecek Veriyi Seçin!");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox3.Text= dataGridView1.CurrentRow.Cells[4].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                comboBox3.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();

            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
        private void ClearData()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            comboBox3.Text = "";
            ID = 0;
        }
        //ID variable used in Updating and Deleting Record  
        int ID = 0;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        private void button4_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text==""||textBox2.Text==""||textBox3.Text==""||textBox4.Text=="")
            //{
            //    MessageBox.Show("Silinecek öğeyi seçin!");
            //}
            //else
            //{
            //    try
            //    {
            //        baglan.Open();
            //        string sorgu = "update from uye set adsoyad='"+textBox1.Text+"',telefon='"+textBox2.Text+ "',cinsiyet='" + comboBox1.Text + "',yas='" + textBox3.Text + "',odeme='" + textBox4.Text + "',zaman='" + comboBox3.Text + "' where id="+key+";";
            //        SqlCommand kmt = new SqlCommand(sorgu, baglan);
            //        kmt.ExecuteNonQuery();
            //        MessageBox.Show("Başarıyla Güncellendi!");
            //        baglan.Close();
            //        uyeler();
            //    }
            //    catch (Exception ex)
            //    {

            //        MessageBox.Show(ex.Message);
            //    }
            // }
         

            if (textBox1.Text != "" || textBox2.Text != "" || textBox3.Text != "" || textBox4.Text != "" )
            {
                cmd = new SqlCommand("update uye set adsoyad=@name,telefon=@tel,cinsiyet=@cins,yas=@yas ,odeme=@ode,zaman=@zaman where id=@id", baglan);
                baglan.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@tel", textBox2.Text);
                cmd.Parameters.AddWithValue("@yas", textBox3.Text);
                cmd.Parameters.AddWithValue("@cins",comboBox1.Text);
                cmd.Parameters.AddWithValue("@ode", textBox4.Text);
                cmd.Parameters.AddWithValue("@zaman", comboBox3.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Başarıyla Eklendi!");
                baglan.Close();
                uyeler();
                ClearData();

            }
            else
            {
                MessageBox.Show("Lütfen Güncellenecek Veriyi Seçin!");
            }

        }
    }
}
